//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import window_size

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  WindowSizePlugin.register(with: registry.registrar(forPlugin: "WindowSizePlugin"))
}
